UMDL
===
The code implementation for the paper: Unbalanced Multi-view Deep Learning

# Environments
  + python 3.7.0
  + pytorch 1.7.1
  + numpy 1.21.6

# Running
```
python main.py

```
